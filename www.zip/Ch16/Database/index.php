<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>通訊錄管理</title>
</head>
<body>
<h2>通訊錄管理</h2><hr/>
<ul>
<li><a href="index.php">通訊錄首頁</a></li>
<li><a href="add.php">新增聯絡人</a></li>
<li><a href="search.php">搜尋通訊錄</a></li>
</ul>
</body>
</html>